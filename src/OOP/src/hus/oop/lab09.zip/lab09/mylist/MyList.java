package hus.oop.lab09.mylist;

interface MyList {
    public void add(Object object, int index);
    public void remove(int index);
    public int size();
    public Object get(int index);
    public void add(Object object);
}
