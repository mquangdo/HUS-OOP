package hus.oop.lab7.quest5;

public interface GeometricObject {
    double getPerimeter();
    double getArea();
}
