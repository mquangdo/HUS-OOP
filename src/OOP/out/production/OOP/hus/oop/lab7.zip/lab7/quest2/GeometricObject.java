package hus.oop.lab7.quest2;

interface GeometricObject {
    double getArea();
    double getPerimeter();
}
