package hus.oop.lab7.quest3;

interface Movable {
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
}
