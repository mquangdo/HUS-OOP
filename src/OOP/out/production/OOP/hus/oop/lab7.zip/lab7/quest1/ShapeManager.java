package hus.oop.lab7.quest1;

public class ShapeManager {
    public static void main(String[] args) {

    }
}
