package hus.oop.lab010.question3.ex3;

public interface Sort {
    public int[] sort(int[] arr);
}
