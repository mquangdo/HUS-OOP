package hus.oop.lab010.question1.ex2;

public class Adaptee {
    public void specificExecute() {
        System.out.println("Adaptee executed.");
    }
}
