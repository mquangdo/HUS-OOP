package hus.oop.lab010.question1.ex2;

public class Target {
    public void execute() {
        System.out.println("Target executed.");
    }
}
