package hus.oop.lab010.question3.ex2;

public interface Strategy {
    int execute(int a, int b);
}
