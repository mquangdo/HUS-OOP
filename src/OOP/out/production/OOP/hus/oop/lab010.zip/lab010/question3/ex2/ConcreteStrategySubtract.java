package hus.oop.lab010.question3.ex2;

public class ConcreteStrategySubtract implements Strategy{
    @Override
    public int execute(int a, int b) {
        return a - b;
    }
}
