package hus.oop.lab11.decorator.question1;

public interface Shape {
    void draw();
}
