package hus.oop.lab11.iterator.example.example1;

public interface Iterator {
    boolean hasNext();
    Object next();
}
