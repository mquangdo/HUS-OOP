package hus.oop.lab11.decorator.question1;

public interface ShapeDecorator extends Shape{
    public void draw();

}
