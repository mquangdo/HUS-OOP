package hus.oop.lab11.iterator.question2;
public interface ProfileIterator {
    Profile getNext();
    boolean hasMore();
}
