package hus.oop.lab11.decorator.question2;

public abstract class ToppingDecorator extends IceCream{
    public abstract String addTopping();
}
