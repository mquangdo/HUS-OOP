package hus.oop.lab11.decorator.question1;

public class Circle implements Shape{
    public void draw(){
        System.out.println("Drawing circle");
    }
}
