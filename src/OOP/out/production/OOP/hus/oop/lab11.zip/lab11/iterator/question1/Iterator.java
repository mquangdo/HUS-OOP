package hus.oop.lab11.iterator.question1;

public interface Iterator {
    boolean hasNext();
    Object next();
}
