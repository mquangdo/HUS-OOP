package hus.oop.lab11.observer.quest1;

public interface Subscriber {
    public void update(int state);
}
