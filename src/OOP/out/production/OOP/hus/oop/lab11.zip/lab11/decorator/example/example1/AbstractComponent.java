package hus.oop.lab11.decorator.example.example1;

public abstract class AbstractComponent {
    public abstract void execute();
}
