package hus.oop.lab11.iterator.example.example1;

public interface Menu {
    public Iterator createIterator();
}
