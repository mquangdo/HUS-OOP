package hus.oop.lab11.decorator.question1;

public class Rectangle implements Shape{
    public void draw(){
        System.out.println("Drawing rectangle");
    }
}
