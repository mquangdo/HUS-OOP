package hus.oop.lab11.iterator.question2;

public class Client {
    public static void main(String[] args) {

    }
}
