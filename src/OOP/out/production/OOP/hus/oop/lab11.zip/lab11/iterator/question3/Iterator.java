package hus.oop.lab11.iterator.question3;

public interface Iterator {
    boolean hasNext();
    Object next();
}
