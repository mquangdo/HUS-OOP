package hus.oop.lab11.iterator.question3;

public interface Iterable {
    Iterator createIterator();
}
