package hus.oop.lab11.decorator.question2;

public abstract class IceCream {
    protected String description = "IceCream";
    public abstract String getDescription();

}
