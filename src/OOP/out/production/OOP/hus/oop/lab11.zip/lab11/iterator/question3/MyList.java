package hus.oop.lab11.iterator.question3;

public abstract class MyList implements Iterable  {

}
