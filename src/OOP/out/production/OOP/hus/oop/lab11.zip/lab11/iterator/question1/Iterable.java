package hus.oop.lab11.iterator.question1;

public interface Iterable {
    Iterator getIterator();
}
