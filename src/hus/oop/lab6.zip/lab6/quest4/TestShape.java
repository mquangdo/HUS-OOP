package hus.oop.lab6.quest4;

public class TestShape {
    public static void main(String[] args) {
        Shape shape = new Shape();
    }
}
