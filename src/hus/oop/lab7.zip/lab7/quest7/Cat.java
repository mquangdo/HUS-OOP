package hus.oop.lab7.quest7;

public class Cat extends Animal {
    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}
