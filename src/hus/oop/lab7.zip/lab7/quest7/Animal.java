package hus.oop.lab7.quest7;

abstract class Animal {
    abstract public void greeting();
}
