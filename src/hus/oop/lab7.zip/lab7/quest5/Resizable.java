package hus.oop.lab7.quest5;

public interface Resizable {
    void resize(int percent);
}
